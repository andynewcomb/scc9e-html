if (xBookUtils.inBrainhoneyPlayer()) {
$(window).ready(function ()
{ player.initialize(); }

);
}